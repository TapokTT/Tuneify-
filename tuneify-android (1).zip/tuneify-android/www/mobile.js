/* Tuneify Android: мобильная замена Electron-слоя. Код Deezer/SoundCloud/VK взят из main.js как есть. */
(function(){
const Cap=window.Capacitor,FS=Cap&&Cap.Plugins&&Cap.Plugins.Filesystem;
const ST=u=>u;
const HOSTS=['googlevideo.com','youtube.com','sndcdn.com','soundcloud.com','soundcloud.cloud','dzcdn.net','deezer.com','i.ytimg.com','vk.com','userapi.com','vkuservideo.net','vk-cdn.net','vk.me','vkuseraudio.net'];
const lsk=k=>'tn_'+k;
const fs={existsSync:()=>false,mkdirSync(){},readFileSync(k){const v=localStorage.getItem(lsk(k));if(v==null)throw 0;return v},writeFileSync(k,v){localStorage.setItem(lsk(k),v)}};
const path={join:(...a)=>a.join('/'),dirname:p=>p,extname:p=>(String(p).match(/\.[^./]+$/)||[''])[0],basename:p=>p};
const app={getPath:()=>'.'};
const net={fetch:(u,o)=>fetch(u,o)};
const CACHE=()=>'',SC_CACHE=()=>'sc',keepOnly=()=>{};
const run=async()=>{throw new Error(lastNetErr||'YouTube пока недоступен на телефоне. Используйте Deezer или SoundCloud.')};
let ytReady,scState={id:'',exp:0};
let lastNetErr='',scIdPromise=null;
const hostOf=u=>{try{return new URL(u).hostname}catch(e){return String(u)}};
const withTimeout=(p,ms)=>new Promise((ok,no)=>{const t=setTimeout(()=>no(new Error('timeout')),ms);p.then(v=>{clearTimeout(t);ok(v)},e=>{clearTimeout(t);no(e)})});
function why(m,ms){m=String(m||'').toLowerCase();
 if(/timeout|timed out/.test(m))return'нет ответа за '+Math.round(ms/1000)+' с';
 if(/unable to resolve|unknownhost|resolve|dns|nodename/.test(m))return'не найден адрес сервера (DNS)';
 if(/refused|unreachable|reset|ssl|handshake|cert|closed/.test(m))return'соединение сорвано или заблокировано';
 return m.slice(0,120)}
async function nativeGet(url,headers,ms){
 try{
  let r;
  if(CH&&CH.request)r=await withTimeout(CH.request({url,method:'GET',headers,responseType:'text',connectTimeout:Math.min(ms,7000),readTimeout:ms}),ms+1500);
  else{const c=new AbortController(),tm=setTimeout(()=>c.abort(),ms);try{const x=await fetch(url,{headers,signal:c.signal});r={status:x.status,data:await x.text()}}finally{clearTimeout(tm)}}
  lastNetErr='';
  return{status:r.status,text:typeof r.data==='string'?r.data:JSON.stringify(r.data)};
 }catch(e){
  const raw=String(e&&(e.message||e.errorMessage)||e);
  const er=new Error(hostOf(url)+': '+why(raw,ms));er.timeout=/timeout|timed out/i.test(raw);lastNetErr=er.message;throw er;
 }
}
async function httpGet(url,extra={},tries=2){
 const h={'User-Agent':UA,Accept:'application/json,text/javascript,*/*',Origin:'https://soundcloud.com',Referer:'https://soundcloud.com/',...(extra.headers||{})};
 Object.keys(h).forEach(k=>h[k]===undefined&&delete h[k]);
 const ms=Math.min(extra.timeout||12000,15000);let last;
 for(let i=0;i<tries;i++){
  try{const r=await nativeGet(url,h,ms);
   if(r.status>=400){const e=new Error(hostOf(url)+': HTTP '+r.status);e.status=r.status;lastNetErr=e.message;throw e}
   if(extra.text)return r.text;
   try{return JSON.parse(r.text)}catch(e){return r.text}
  }catch(e){last=e;if(e.timeout)break;if(e.status&&e.status>=400&&e.status<500&&e.status!==408&&e.status!==429)break;await sleep(300)}
 }
 throw last;
}
async function dzFetch(url){
 let last;
 for(let i=0;i<2;i++){
  try{const r=await nativeGet(url,{Accept:'application/json'},10000);
   if(r.status>=400)throw new Error('api.deezer.com: HTTP '+r.status);
   const data=JSON.parse(r.text);return{ok:true,json:async()=>data};
  }catch(e){last=e;if(e.timeout)break;await sleep(300)}
 }
 throw new Error('Deezer недоступен — '+(last&&last.message||last)+'. Если он заблокирован в вашей сети, включите VPN на телефоне.');
}
async function scClientId(){
 if(scState.id&&scState.exp>Date.now())return scState.id;
 loadScCache();
 if(scState.id&&scState.exp>Date.now())return scState.id;
 if(scIdPromise)return scIdPromise;
 scIdPromise=(async()=>{
  const html=await httpGet('https://soundcloud.com',{text:true,timeout:12000},2);
  const pool=[...html.matchAll(/src="(https:\/\/[a-z0-9.-]+\.sndcdn\.com\/assets\/[^"]+\.js)"/g)].map(m=>m[1]).slice(-8).reverse();
  return await new Promise((ok,no)=>{let left=pool.length,done=false;
   const fail=()=>no(new Error(lastNetErr||'не удалось получить ключ SoundCloud'));
   if(!left)return fail();
   pool.forEach(u=>httpGet(u,{text:true,timeout:15000},1).then(js=>{
    const m=js.match(/client_id\s*[:=]\s*["']([A-Za-z0-9]{32})["']/)||js.match(/client_id=([A-Za-z0-9]{32})/);
    if(m&&!done){done=true;scState={id:m[1],exp:Date.now()+12*3600*1000};saveScCache();ok(m[1])}
   }).catch(()=>{}).finally(()=>{if(--left===0&&!done)fail()}));
  });
 })().finally(()=>{scIdPromise=null});
 return scIdPromise;
}
function diagBtn(){if(document.getElementById('tn-diag-btn'))return;const b=document.createElement('button');b.id='tn-diag-btn';b.textContent='Проверить сеть';
 b.style.cssText='position:fixed;top:calc(env(safe-area-inset-top,0px) + 8px);right:8px;z-index:99999;padding:8px 12px;border-radius:999px;border:0;background:#e5484d;color:#fff;font:600 13px system-ui';b.onclick=runDiag;document.body.appendChild(b)}
async function runDiag(){
 const old=document.getElementById('tn-diag');if(old)old.remove();
 const box=document.createElement('div');box.id='tn-diag';
 box.style.cssText='position:fixed;inset:0;z-index:100000;background:rgba(0,0,0,.88);color:#fff;font:14px/1.6 system-ui;padding:calc(env(safe-area-inset-top,0px) + 16px) 16px 16px;overflow:auto;white-space:pre-wrap';
 document.body.appendChild(box);box.textContent='Проверяю…';
 const T=[['Интернет (контроль)','https://www.gstatic.com/generate_204'],['Deezer API','https://api.deezer.com/search?limit=1&q=test'],['SoundCloud сайт','https://soundcloud.com'],['SoundCloud API','https://api-v2.soundcloud.com/']];
 const lines=await Promise.all(T.map(async([n,u])=>{const t0=Date.now();try{const r=await nativeGet(u,{'User-Agent':UA},10000);return'✔ '+n+': ответ '+r.status+', '+(Date.now()-t0)+' мс'}catch(e){return'✖ '+n+': '+e.message+' ('+(Date.now()-t0)+' мс)'}}));
 box.textContent='Проверка сети\n\n'+lines.join('\n')+'\n\nЕсли контроль работает, а Deezer/SoundCloud нет, включите VPN на телефоне и повторите поиск.\n\n';
 const c=document.createElement('button');c.textContent='Закрыть';c.style.cssText='padding:10px 18px;border-radius:10px;border:0;font:600 14px system-ui';c.onclick=()=>box.remove();box.appendChild(c);
}
const guard=p=>p.catch(e=>{try{diagBtn()}catch(_){}throw e});
const memo=new Map();
const memoSearch=(s,q)=>{const k=s+'|'+q,h=memo.get(k);if(h&&Date.now()-h.t<300000)return Promise.resolve(h.v);
 return guard(search(s,q).then(v=>{memo.set(k,{t:Date.now(),v});const b=document.getElementById('tn-diag-btn');if(b)b.remove();return v}))};

const bestCover=(e)=>(e.thumbnails&&e.thumbnails.length?e.thumbnails[e.thumbnails.length-1].url:'');
const artistName=(e)=>(e.channel||e.uploader||e.artist||'Неизвестный').replace(/ - Topic$/,'');
const CH=Cap&&Cap.Plugins&&Cap.Plugins.CapacitorHttp;
const UA='Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
function allowedHost(hostname) {
  return HOSTS.some(h => hostname === h || hostname.endsWith('.' + h));
}

function loadScCache() {
  try {
    const j = JSON.parse(fs.readFileSync(SC_CACHE(), 'utf8'));
    if (j.id && j.exp > Date.now()) scState = j;
  } catch (e) {}
}
function saveScCache() {
  try { fs.mkdirSync(path.dirname(SC_CACHE()), { recursive: true }); fs.writeFileSync(SC_CACHE(), JSON.stringify(scState)); } catch (e) {}
}


function scArt(url) {
  if (!url) return '';
  return url.replace('-large.', '-t500x500.').replace('-tiny.', '-t500x500.');
}
function scCover(t) {
  const u = scArt((t && (t.artwork_url || (t.user && t.user.avatar_url))) || '');
  return u ? ST(u) : '';
}
function mapScTrack(t) {
  if (!t || !t.id) return null;
  const user = t.user || {};
  return {
    src: 'sc',
    rid: String(t.permalink_url || t.uri || t.id),
    sid: String(t.id),
    title: t.title || 'Без названия',
    artist: user.username || user.full_name || 'Неизвестный',
    cover: scCover(t),
    dur: t.duration ? Math.round(t.duration / 1000) : 0,
    aid: String(user.id || ''),
    permalink: user.permalink_url || ''
  };
}
function mapScUser(u) {
  if (!u || !u.id) return null;
  const av = scArt(u.avatar_url || '');
  return {
    src: 'sc',
    aid: String(u.id),
    name: u.username || u.full_name,
    cover: av ? ST(av) : '',
    fans: u.followers_count || 0,
    permalink: u.permalink_url || ''
  };
}
function mapScPl(p) {
  if (!p || !p.id) return null;
  const user = p.user || {};
  return {
    src: 'sc',
    pid: String(p.id),
    title: p.title || 'Плейлист',
    artist: user.username || '',
    cover: scCover(p),
    count: p.track_count || (p.tracks && p.tracks.length) || 0,
    permalink: p.permalink_url || ''
  };
}

async function scApi(pathname, params = {}) {
  const id = await scClientId();
  const u = /^https?:\/\//i.test(pathname)
    ? new URL(pathname)
    : new URL('https://api-v2.soundcloud.com' + pathname);
  if (u.protocol !== 'https:' || u.hostname !== 'api-v2.soundcloud.com')
    throw new Error('недопустимый адрес SoundCloud API');
  u.searchParams.set('client_id', id);
  u.searchParams.set('app_locale', 'en');
  for (const [k, v] of Object.entries(params)) if (v != null && v !== '') u.searchParams.set(k, String(v));
  try {
    return await httpGet(u.toString(), { timeout: 22000 });
  } catch (e) {
    if (e.status && e.status !== 401 && e.status !== 403) throw e;
    scState = { id: '', exp: 0 };
    saveScCache();
    const id2 = await scClientId();
    u.searchParams.set('client_id', id2);
    return await httpGet(u.toString(), { timeout: 22000 });
  }
}

async function scCollection(pathname, params = {}) {
  const items = [];
  const seenPages = new Set();
  let next = pathname;
  let query = { limit: 200, linked_partitioning: 1, ...params };

  while (next) {
    const pageKey = next + JSON.stringify(query);
    if (seenPages.has(pageKey)) throw new Error('SoundCloud повторил страницу плейлиста');
    seenPages.add(pageKey);
    const result = await scApi(next, query);
    items.push(...(Array.isArray(result) ? result : result.collection || []));
    next = !Array.isArray(result) && result.next_href ? result.next_href : '';
    query = {};
  }
  return items;
}

async function scSearch(q) {
  const [tracks, users, playlists] = await Promise.all([
    scApi('/search/tracks', { q, limit: 25, offset: 0 }),
    scApi('/search/users', { q, limit: 12, offset: 0 }),
    scApi('/search/playlists', { q, limit: 12, offset: 0 })
  ]);
  return {
    tracks: (tracks.collection || tracks || []).map(mapScTrack).filter(Boolean),
    artists: (users.collection || users || []).map(mapScUser).filter(Boolean),
    playlists: (playlists.collection || playlists || []).map(mapScPl).filter(Boolean)
  };
}

async function scArtist(aid) {
  let user;
  if (/^\d+$/.test(String(aid))) {
    user = await scApi('/users/' + aid);
  } else {
    const permalink = String(aid).replace(/^https?:\/\/(www\.)?soundcloud\.com\//, '').split('?')[0].replace(/\/$/, '');
    const r = await scApi('/resolve', { url: 'https://soundcloud.com/' + permalink });
    user = r.kind === 'user' ? r : r.user || r;
  }
  const tracks = await scApi('/users/' + user.id + '/tracks', { limit: 50, offset: 0 });
  return {
    info: mapScUser(user),
    tracks: (tracks.collection || tracks || []).map(mapScTrack).filter(Boolean)
  };
}

async function scPlaylistViaYtDlp(permalink, info) {
  const j = JSON.parse(await run([
    '--dump-single-json', '--flat-playlist',
    '--no-warnings', '--socket-timeout', '25', permalink
  ], 180000));
  const tracks = (j.entries || []).filter(e => e && e.title).map(e => mapYtSc('sc', e));
  if (!tracks.length) throw new Error('yt-dlp не нашёл треки в плейлисте');
  return {
    info: info || {
      src: 'sc', pid: permalink, title: j.title || 'Плейлист',
      artist: j.uploader || '', cover: bestCover(j),
      count: j.playlist_count || tracks.length, permalink
    },
    tracks
  };
}

async function scPlaylist(reference) {
  const isUrl = /^https?:\/\//i.test(String(reference));
  let p;
  try {
    p = isUrl
      ? await scApi('/resolve', { url: reference })
      : await scApi('/playlists/' + reference, { representation: 'full' });
  } catch (e) {
    if (!isUrl) throw e;
    console.warn('[tuneify] SoundCloud playlist API failed; trying yt-dlp:', e.message);
    try { return await scPlaylistViaYtDlp(reference); }
    catch (fallbackError) {
      throw new Error('Не удалось загрузить плейлист SoundCloud: ' + e.message + '; резервный способ: ' + fallbackError.message);
    }
  }
  let tracks = p.tracks || [];
  const missing = tracks.filter(t => t && t.id && !t.title).map(t => t.id);
  if (missing.length) {
    const byId = {};
    const chunks = [];
    for (let i = 0; i < missing.length; i += 40) chunks.push(missing.slice(i, i + 40));
    // грузим пачками по 40 id, по 3 запроса параллельно
    for (let i = 0; i < chunks.length; i += 3) {
      await Promise.all(chunks.slice(i, i + 3).map(async (ids) => {
        for (let attempt = 0; attempt < 2; attempt++) {
          try {
            const extra = await scApi('/tracks', { ids: ids.join(',') });
            for (const t of (extra.collection || extra || [])) if (t && t.id) byId[String(t.id)] = t;
            return;
          } catch (e) {
            if (attempt) console.warn('[tuneify] SoundCloud track metadata lookup failed:', e.message);
          }
        }
      }));
    }
    tracks = tracks.map(t => (t && t.title) ? t : byId[String(t && t.id)] || t);
  }
  const info = mapScPl(p);
  const permalink = p.permalink_url || (isUrl ? reference : '');
  const expectedCount = Number(p.track_count || 0);
  let fallbackError;
  const untitled = tracks.filter(t => t && !t.title).length;
  console.log('[tuneify] sc playlist:', (p.title || reference), '— в списке', tracks.length, ', без данных', untitled, ', заявлено', expectedCount);
  if ((untitled > tracks.length * 0.3 || (expectedCount && tracks.length < expectedCount * 0.5)) && permalink) {
    try { return await scPlaylistViaYtDlp(permalink, info); }
    catch (e) {
      fallbackError = e;
      console.error('[tuneify] sc playlist metadata fallback:', e.message);
    }
  }
  const mappedTracks = tracks.map(t => {
    const mapped = mapScTrack(t);
    if (mapped && mapped.artist === 'Неизвестный' && p.user)
      mapped.artist = p.user.username || p.user.full_name || mapped.artist;
    return mapped;
  }).filter(t => t && t.title !== 'Без названия');
  if (!mappedTracks.length && tracks.length)
    throw new Error('SoundCloud не вернул названия треков' + (fallbackError ? '; резервная загрузка не сработала: ' + fallbackError.message : ''));
  if (expectedCount && mappedTracks.length < expectedCount)
    console.warn('[tuneify] SoundCloud: загружено ' + mappedTracks.length + ' из ' + expectedCount + ' (остальные удалены, приватны или недоступны)');
  if (!mappedTracks.length)
    throw new Error('SoundCloud не вернул треки плейлиста' + (fallbackError ? '; резервная загрузка не сработала: ' + fallbackError.message : ''));
  return { info, tracks: mappedTracks };
}

async function scStream(t) {
  const id = t.sid || (String(t.rid).match(/\/(\d+)$/) || [])[1];
  let track;
  if (id && /^\d+$/.test(id)) track = await scApi('/tracks/' + id);
  else track = await scApi('/resolve', { url: t.rid });
  const trans = (track.media && track.media.transcodings) || [];
  const progressive = trans.find(x => x.format && x.format.protocol === 'progressive') || trans[0];
  if (!progressive || !progressive.url) throw new Error('у трека SoundCloud нет потока');
  const cid = await scClientId();
  const sep = progressive.url.includes('?') ? '&' : '?';
  const info = await httpGet(progressive.url + sep + 'client_id=' + cid, { timeout: 20000 });
  const url = info.url || info.http_mp3_128_url;
  if (!url) throw new Error('SoundCloud не отдал ссылку на аудио');
  return url;
}

const VK_API = 'https://api.vk.com/method/';
const VK_V = '5.199';
function vkUnobfuscateUrl(url) {
  if (!url || typeof url !== 'string') return '';
  if (!url.includes('m3u8') && !url.includes('index.m3u8') && (url.startsWith('http://') || url.startsWith('https://')) && /\.mp3(\?|$)/i.test(url)) return url.split('?')[0];
  if (url.includes('api.vk.com') || url.includes('redirect')) return url;
  try {
    const m = url.match(/\/assets\/audio-[-a-z0-9]+\/([a-f0-9]+)\/index\.m3u8\?.*?extra=([A-Za-z0-9_\-]+)/);
    if (!m) return url;
  } catch (e) {}
  return url;
}
// VK показывает вместо музыки заглушку «Аудио доступно на vk.com и в официальных приложениях» (~25 с).
const VK_STUB = /доступно на vk\.com|в официальных приложениях/i;
const vkReal = (t) => !!t && !VK_STUB.test((t.title || '') + ' ' + (t.artist || ''));
const VK_STUB_MSG = 'VK не отдаёт музыку сторонним приложениям: вместо треков показывается заглушка «Аудио доступно на vk.com и в официальных приложениях». Для этого запроса попробуйте Deezer, SoundCloud или YouTube.';
function mapVkTrack(a) {
  if (!a) return null;
  const url = (a.url && typeof a.url === 'string' && !a.url.startsWith('action=')) ? vkUnobfuscateUrl(a.url) : '';
  const cover = (a.album && a.album.thumb && (a.album.thumb.photo_300 || a.album.thumb.photo_270 || a.album.thumb.photo_135)) || '';
  const rid = a.full_id || [a.owner_id, a.id, a.access_key || ''].filter(Boolean).join('_');
  return {
    src: 'vk',
    rid: String(rid || ''),
    sid: String(a.id || ''),
    title: a.title || 'Без названия',
    artist: a.artist || 'Неизвестный',
    cover: cover || '',
    dur: Math.round((a.duration || 0)),
    url: url,
    aid: String(a.owner_id || ''),
    _vkUrl: url
  };
}
async function vkApi(method, params, token) {
  if (!token) throw new Error('нет токена VK — введите его в Настройки → VK Музыка');
  const u = new URL(VK_API + method);
  u.searchParams.set('access_token', token);
  u.searchParams.set('v', VK_V);
  for (const k in params) if (params[k] != null && params[k] !== '') u.searchParams.set(k, String(params[k]));
  const r = await httpGet(u.toString(), { timeout: 30000, headers: { Origin: undefined, Referer: undefined } });
  if (r && r.error) {
    const e = r.error || {};
    const m = e.error_msg || ('VK ошибка ' + (e.error_code || '?'));
    if ([5, 1114, 1115, 10, 15].includes(+e.error_code)) throw new Error('Токен VK недействителен или истёк — получите новый и вставьте в Настройки. (' + m + ')');
    if (+e.error_code === 27 || +e.error_code === 201) throw new Error('Нужен токен с правами audio (scope=audio,audiooffline). ' + m);
    throw new Error('VK API: ' + m);
  }
  return (r && r.response != null) ? r.response : null;
}
async function vkAudioSearch(q, token, opts) {
  const count = Math.min(300, (opts && opts.count) || 150);
  const resp = await vkApi('audio.search', {
    q, count,
    sort: opts && opts.sort || 0,
    offset: opts && opts.offset || 0,
    search_own: (opts && opts.own) ? 1 : 0
  }, token);
  let arr = [];
  if (Array.isArray(resp)) arr = resp;
  else if (resp && Array.isArray(resp.items)) arr = resp.items;
  else if (resp && Array.isArray(resp.response)) arr = resp.response;
  else if (resp && resp.response && Array.isArray(resp.response.items)) arr = resp.response.items;
  return arr.map(mapVkTrack).filter(Boolean).filter(t => t.title && t.artist).filter(vkReal);
}
async function vkAudioGetById(ids, token) {
  if (!ids || !ids.length) return [];
  const resp = await vkApi('audio.getById', { audios: ids.join(',') }, token);
  let arr = [];
  if (Array.isArray(resp)) arr = resp;
  else if (resp && Array.isArray(resp.response)) arr = resp.response;
  else if (resp && Array.isArray(resp.items)) arr = resp.items;
  return arr.map(mapVkTrack).filter(Boolean);
}
let vkTokenCache='';
function getVkToken(){return vkTokenCache||(vkTokenCache=localStorage.getItem(lsk('vk'))||'')}
function setVkToken(t){vkTokenCache=String(t||'').trim();localStorage.setItem(lsk('vk'),vkTokenCache);return vkTokenCache}
async function vkAudioTest(token) {
  const resp = await vkApi('users.get', {}, token || getVkToken());
  let u = null;
  if (Array.isArray(resp)) u = resp[0];
  else if (resp && Array.isArray(resp.response)) u = resp.response[0];
  else if (resp && !Array.isArray(resp) && (resp.id || resp.first_name)) u = resp;
  return { ok: true, user: u || null };
}
function mapYtSc(src, e) {
  return {
    src, rid: src === 'yt' ? e.id : (e.webpage_url || e.url),
    title: e.title, artist: artistName(e),
    cover: src === 'yt' ? `https://i.ytimg.com/vi/${e.id}/hqdefault.jpg` : bestCover(e),
    dur: e.duration,
    aid: src === 'yt' ? (e.channel_id || '') : (e.uploader_url || e.channel_url || e.webpage_url || '')
  };
}

// ---- Deezer API через сетевой стек Electron (Chromium) ----
// Встроенный в Node fetch игнорирует системный прокси/VPN и обрывается через 10 с,
// поэтому ходим через net.fetch, как и для остальных сервисов. Есть таймаут и повтор.


async function search(src, q) {
  q = String(q || '').trim();
  if (!q) return { tracks: [], artists: [], playlists: [] };
  if (src === 'sc') {
    try { return await scSearch(q); }
    catch (e) {
      console.error('[tuneify] sc api:', e.message);
      const j = JSON.parse(await run(['--dump-single-json', '--flat-playlist', '--no-warnings', '--socket-timeout', '25', 'scsearch15:' + q], 90000));
      const entries = (j.entries || []).filter(Boolean);
      return { tracks: entries.map(x => mapYtSc('sc', x)), artists: [], playlists: [] };
    }
  }
  if (src === 'dz') {
    const [tj, aj, pj] = await Promise.all([
      dzFetch('https://api.deezer.com/search?limit=25&q=' + encodeURIComponent(q)).then(r => r.json()),
      dzFetch('https://api.deezer.com/search/artist?limit=10&q=' + encodeURIComponent(q)).then(r => r.json()),
      dzFetch('https://api.deezer.com/search/playlist?limit=10&q=' + encodeURIComponent(q)).then(r => r.json())
    ]);
    return {
      tracks: (tj.data || []).map(t => ({
        src: 'dz', rid: String(t.id), title: t.title, artist: t.artist.name,
        cover: t.album.cover_medium, dur: t.duration, pg: t.preview, aid: String(t.artist.id)
      })),
      artists: (aj.data || []).map(a => ({
        src: 'dz', aid: String(a.id), name: a.name, cover: a.picture_medium, fans: a.nb_fan
      })),
      playlists: (pj.data || []).map(p => ({
        src: 'dz', pid: String(p.id), title: p.title, artist: (p.user && p.user.name) || '',
        cover: p.picture_medium, count: p.nb_tracks
      }))
    };
  }
  if (src === 'vk') {
    const token = getVkToken();
    if (token && !/^https?:\/\//.test(q)) {
      try {
        const tracks = await vkAudioSearch(q, token, { count: 150 });
        return { tracks, artists: [], playlists: [] };
      } catch (e) {
        console.error('[tuneify] vk api search:', e.message);
      }
    }
    const page = /^https?:\/\//.test(q) ? q : 'https://vk.com/audio?q=' + encodeURIComponent(q);
    try {
      const j = JSON.parse(await run(['--dump-single-json', '--flat-playlist', '--playlist-end', '20', '--no-warnings', page], 90000));
      const entries = (j.entries || [j]).filter(e => e && (e.id || e.url || e.webpage_url));
      const vkTracks = entries.map(e => mapYtSc('vk', e)).filter(vkReal);
      if (!vkTracks.length) throw new Error(VK_STUB_MSG);
      return { tracks: vkTracks, artists: [], playlists: [] };
    } catch (e) {
      if (e.message === VK_STUB_MSG) throw e;
      throw new Error((token ? 'VK API не вернул результат — попробуйте другой запрос или вставьте прямую ссылку vk.com/audio… ' : 'Введите токен VK в Настройки → VK Музыка, чтобы поиск работал как в официальном приложении (150 результатов за раз, играют сразу без ожидания). ') + 'Или вставьте прямую ссылку на аудио/клип vk.com. Детали: ' + e.message);
    }
  }
  const prefix = src === 'yt' ? 'ytsearch15:' : 'scsearch15:';
  const j = JSON.parse(await run(['--dump-single-json', '--flat-playlist', '--no-warnings', '--socket-timeout', '20', prefix + q], 90000));
  const entries = (j.entries || []).filter(Boolean);
  const tracks = entries.map(e => mapYtSc(src, e));
  const seen = new Set();
  const artists = [];
  for (const e of entries) {
    const name = artistName(e);
    const aid = src === 'yt' ? e.channel_id : (e.uploader_url || e.channel_url);
    if (!aid || seen.has(aid)) continue;
    seen.add(aid);
    artists.push({
      src, aid, name,
      cover: src === 'yt' ? `https://i.ytimg.com/vi/${e.id}/hqdefault.jpg` : bestCover(e)
    });
  }
  return { tracks, artists, playlists: [] };
}

async function artist(src, aid) {
  aid = String(aid || '').trim();
  if (!aid) return { info: null, tracks: [], playlists: [] };
  if (src === 'sc') {
    try {
      const r = await scArtist(aid);
      let playlists = [];
      try {
        const uid = (r.info && r.info.aid) || aid;
        const pl = await scApi('/users/' + uid + '/playlists', { limit: 20, offset: 0 });
        playlists = (pl.collection || pl || []).map(mapScPl).filter(Boolean);
      } catch (e) {}
      return { ...r, playlists };
    } catch (e) {
      console.error('[tuneify] sc artist:', e.message);
      const page = /^\d+$/.test(aid) ? aid : (aid.startsWith('http') ? aid : 'https://soundcloud.com/' + aid.replace(/^https?:\/\/(www\.)?soundcloud\.com\//, ''));
      const j = JSON.parse(await run(['--dump-single-json', '--flat-playlist', '--playlist-end', '40', '--no-warnings', '--socket-timeout', '25', page], 90000));
      const entries = (j.entries || []).filter(Boolean);
      return {
        info: { src: 'sc', aid, name: (j.uploader || j.title || artistName(entries[0] || {})), cover: bestCover(j) || bestCover(entries[0] || {}) },
        tracks: entries.map(x => mapYtSc('sc', x)),
        playlists: []
      };
    }
  }
  if (src === 'dz') {
    const [info, top, pls] = await Promise.all([
      dzFetch('https://api.deezer.com/artist/' + encodeURIComponent(aid)).then(r => r.json()),
      dzFetch('https://api.deezer.com/artist/' + encodeURIComponent(aid) + '/top?limit=50').then(r => r.json()),
      dzFetch('https://api.deezer.com/artist/' + encodeURIComponent(aid) + '/playlists?limit=20').then(r => r.json()).catch(() => ({ data: [] }))
    ]);
    return {
      info: { src: 'dz', aid: String(info.id || aid), name: info.name, cover: info.picture_xl || info.picture_medium, fans: info.nb_fan },
      tracks: (top.data || []).map(t => ({
        src: 'dz', rid: String(t.id), title: t.title, artist: (t.artist && t.artist.name) || info.name,
        cover: t.album && t.album.cover_medium, dur: t.duration, aid: String(info.id || aid)
      })),
      playlists: (pls.data || []).map(p => ({
        src: 'dz', pid: String(p.id), title: p.title, artist: info.name,
        cover: p.picture_medium, count: p.nb_tracks
      }))
    };
  }
  const page = src === 'yt'
    ? (aid.startsWith('http') ? aid : 'https://www.youtube.com/channel/' + aid + '/videos')
    : aid;
  const j = JSON.parse(await run(['--dump-single-json', '--flat-playlist', '--playlist-end', '40', '--no-warnings', '--socket-timeout', '20', page], 90000));
  const entries = (j.entries || []).filter(Boolean);
  const name = (j.channel || j.uploader || j.title || artistName(entries[0] || {})).replace(/ - Topic$/, '');
  return {
    info: {
      src, aid, name,
      cover: src === 'yt' && entries[0] ? `https://i.ytimg.com/vi/${entries[0].id}/hqdefault.jpg` : (bestCover(j) || bestCover(entries[0] || {}))
    },
    tracks: entries.map(e => mapYtSc(src, e)),
    playlists: []
  };
}

async function playlist(src, pid) {
  if (src === 'sc') return scPlaylist(pid);
  if (src === 'dz') {
    const p = await dzFetch('https://api.deezer.com/playlist/' + encodeURIComponent(pid)).then(r => r.json());
    return {
      info: { src: 'dz', pid: String(p.id || pid), title: p.title, artist: p.creator && p.creator.name, cover: p.picture_medium, count: p.nb_tracks },
      tracks: ((p.tracks && p.tracks.data) || []).map(t => ({
        src: 'dz', rid: String(t.id), title: t.title, artist: t.artist && t.artist.name,
        cover: t.album && t.album.cover_medium, dur: t.duration, aid: t.artist && String(t.artist.id)
      }))
    };
  }
  return { info: null, tracks: [] };
}

// ---- Deezer: полный трек ----
// Публичный API Deezer отдаёт только 30-секундные превью (полные файлы у Deezer зашифрованы,
// их мы не трогаем). Поэтому для полного прослушивания ищем тот же трек на SoundCloud / YouTube
// и играем его, а название, исполнителя и обложку оставляем от Deezer.
const dzFullCache = new Map();
const dzNorm = (s) => String(s || '').toLowerCase()
  .replace(/\(.*?\)|\[.*?\]/g, ' ').replace(/\b(feat|ft)\b.*$/, ' ')
  .replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
function dzPickBest(t, list) {
  const title = dzNorm(t.title), artist = dzNorm(t.artist);
  let best = null, bestScore = 0;
  for (const c of list) {
    const ct = dzNorm(c.title), ca = dzNorm(c.artist);
    if (!ct) continue;
    if (!(ct.includes(title) || title.includes(ct))) continue;      // название должно совпасть
    let score = 1;
    if (artist && (ct.includes(artist) || ca.includes(artist) || artist.includes(ca))) score += 2;
    if (t.dur && c.dur) {
      const d = Math.abs(t.dur - c.dur);
      if (d > 12) continue;                                          // длительность должна быть близкой
      score += d <= 3 ? 2 : 1;
    }
    if (c.dur && c.dur <= 45 && (!t.dur || t.dur > 60)) continue;    // отсекаем превью-обрезки
    if (/\b(remix|cover|live|karaoke|slowed|sped up|nightcore|8d)\b/i.test(c.title) &&
        !/\b(remix|cover|live|karaoke|slowed|sped up|nightcore|8d)\b/i.test(t.title)) continue;
    if (score > bestScore) { best = c; bestScore = score; }
  }
  if (!best) console.log('[tuneify] dz: нет подходящего совпадения среди', list.length, 'вариантов');
  return bestScore >= 2 ? best : null;
}
async function dzFindFull(t) {
  const key = String(t.rid);
  if (dzFullCache.has(key)) {
    const c = dzFullCache.get(key);
    const m = c.startsWith('app://media/') ? decodeURIComponent(c.slice('app://media/'.length)) : null;
    if (!m || fs.existsSync(m)) return c;
    dzFullCache.delete(key);
  }
  const q = (t.artist ? t.artist + ' ' : '') + t.title;
  let result = null;
  try {
    const r = await scApi('/search/tracks', { q, limit: 10, offset: 0 });
    const list = (r.collection || r || []).map(mapScTrack).filter(Boolean);
    const best = dzPickBest(t, list);
    if (best) { console.log('[tuneify] dz -> SoundCloud:', best.artist, '-', best.title); result = ST(await scStream(best)); }
  } catch (e) { console.warn('[tuneify] dz->sc:', e.message); }
  if (!result) {
    try {
      const j = JSON.parse(await run(['--dump-single-json', '--flat-playlist', '--no-warnings', '--socket-timeout', '20', 'ytsearch8:' + q], 90000));
      const list = (j.entries || []).filter(Boolean).map(e => mapYtSc('yt', e));
      const best = dzPickBest(t, list);
      if (best) {
        console.log('[tuneify] dz -> YouTube:', best.artist, '-', best.title);
        fs.mkdirSync(CACHE(), { recursive: true });
        const out = (await run(['-f', 'bestaudio/best', '--no-playlist', '--no-warnings', '--no-simulate', '--print', 'after_move:filepath',
          '-o', path.join(CACHE(), '%(extractor)s-%(id)s.%(ext)s'), 'https://www.youtube.com/watch?v=' + best.rid], 180000)).trim().split('\n').pop();
        if (out && fs.existsSync(out)) { keepOnly(out); result = 'app://media/' + encodeURIComponent(out); }
      }
    } catch (e) { console.warn('[tuneify] dz->yt:', e.message); }
  }
  if (result) dzFullCache.set(key, result);
  return result;
}

async function resolve(t) {
  let url;
  if (t.src === 'dz') {
    const j = await (await dzFetch('https://api.deezer.com/track/' + t.rid)).json();
    const meta = {
      rid: t.rid,
      title: t.title || j.title,
      artist: t.artist || (j.artist && j.artist.name) || '',
      dur: t.dur || j.duration || 0
    };
    const full = await dzFindFull(meta).catch(e => { console.warn('[tuneify] dz full:', e.message); return null; });
    if (full) return full;
    console.warn('[tuneify] полная версия «' + meta.artist + ' — ' + meta.title + '» не найдена, играю 30-секундное превью Deezer');
    url = j.preview;
  } else if (t.src === 'sc') {
    try {
      url = await scStream(t);
    } catch (e) {
      console.warn('[tuneify] SoundCloud API stream failed; trying yt-dlp:', e.message);
      try {
        const direct = (await run([
          '--get-url', '-f', 'bestaudio/best', '--no-playlist', '--no-warnings',
          '--socket-timeout', '25', t.rid
        ], 90000)).trim().split('\n').find(x => /^https:\/\//i.test(x));
        if (!direct) throw new Error('yt-dlp не вернул прямую ссылку');
        url = direct;
      } catch (fallbackError) {
        throw new Error('SoundCloud не смог получить поток: ' + e.message + '; резервный способ: ' + fallbackError.message);
      }
    }
  } else if (t.src === 'vk') {
    const token = getVkToken();
    if (t._vkUrl && (t._vkUrl.startsWith('http://') || t._vkUrl.startsWith('https://')) && /\.mp3(\?|$)/i.test(t._vkUrl)) {
      url = t._vkUrl;
    } else if (token && String(t.rid || '').split('_').length >= 2) {
      try {
        const parts = String(t.rid).split('_');
        const needKey = parts.length >= 3;
        const id = parts.slice(0, needKey ? 3 : 2).join('_');
        const arr = await vkAudioGetById([id], token);
        const found = arr[0];
        if (found && found._vkUrl && /\.mp3(\?|$)/i.test(found._vkUrl)) {
          url = found._vkUrl;
        }
      } catch (e) { console.error('[tuneify] vk resolve API:', e.message); }
    }
    if (!url) {
      const page = /^https?:\/\//.test(t.rid) ? t.rid : 'https://vk.com/audio' + (t.rid ? ('?q=' + encodeURIComponent((t.artist || '') + ' ' + (t.title || ''))) : '');
      fs.mkdirSync(CACHE(), { recursive: true });
      const out = (await run(['-f', 'bestaudio/best', '--no-playlist', '--no-warnings', '--no-simulate', '--print', 'after_move:filepath',
        '-o', path.join(CACHE(), '%(extractor)s-%(id)s.%(ext)s'), page], 180000)).trim().split('\n').pop();
      if (!out || !fs.existsSync(out)) throw new Error('yt-dlp не создал файл для VK трека (и прямая ссылка не нашлась). Проверьте токен VK в Настройках — с ним треки играют напрямую без yt-dlp.');
      keepOnly(out);
      return 'app://media/' + encodeURIComponent(out);
    }
  } else {
    const page = t.src === 'yt' ? 'https://www.youtube.com/watch?v=' + t.rid : t.rid;
    fs.mkdirSync(CACHE(), { recursive: true });
    const out = (await run(['-f', 'bestaudio/best', '--no-playlist', '--no-warnings', '--no-simulate', '--print', 'after_move:filepath',
      '-o', path.join(CACHE(), '%(extractor)s-%(id)s.%(ext)s'), page], 180000)).trim().split('\n').pop();
    if (!out || !fs.existsSync(out)) throw new Error('yt-dlp не создал файл');
    keepOnly(out);
    return 'app://media/' + encodeURIComponent(out);
  }
  if (!url) throw new Error('не удалось получить ссылку на аудио');
  return ST(url);
}

const b64=buf=>{let s='';const u=new Uint8Array(buf);for(let i=0;i<u.length;i+=0x8000)s+=String.fromCharCode.apply(null,u.subarray(i,i+0x8000));return btoa(s)};
const toB64=f=>new Promise((ok,no)=>{const r=new FileReader();r.onload=()=>ok(String(r.result).split(',')[1]);r.onerror=no;r.readAsDataURL(f)});
const ACC={audio:'audio/*',video:'video/*',image:'image/*'};
function pick(kind){return new Promise(res=>{const i=document.createElement('input');i.type='file';i.accept=ACC[kind]||'*/*';i.multiple=kind==='audio';
i.onchange=async()=>{const out=[];for(const f of i.files){const name=f.name.replace(/\.[^.]+$/,'');let p;
try{if(!FS)throw 0;const fn='lib/'+Date.now()+'_'+f.name.replace(/[^\w.-]+/g,'_');const r=await FS.writeFile({path:fn,data:await toB64(f),directory:'DATA',recursive:true});p=Cap.convertFileSrc(r.uri)}catch(e){p=URL.createObjectURL(f)}
out.push({path:p,name})}res(out)};i.oncancel=()=>res([]);i.click()})}
async function saveTrack(t){try{let u=t.url||'';if(!u||u.startsWith('app://'))u=await resolve({src:t.src,rid:t.rid,sid:t.sid});
const r=await fetch(u);if(!r.ok)throw new Error('HTTP '+r.status);const name=((t.artist||'unknown')+' - '+(t.title||'track')).replace(/[\\/:*?"<>|]/g,'_').slice(0,120)+'.mp3';
const w=await FS.writeFile({path:'Tuneify/'+name,data:b64(await r.arrayBuffer()),directory:'DOCUMENTS',recursive:true});return{ok:true,path:w.uri}}catch(e){throw e}}
function onMedia(cb){const ms=navigator.mediaSession;if(!ms)return;[['play','play'],['pause','play'],['nexttrack','next'],['previoustrack','prev']].forEach(([k,a])=>{try{ms.setActionHandler(k,()=>cb(a))}catch(e){}})}
function presence(st){const ms=navigator.mediaSession;if(!ms||!st||st.clear){if(ms)ms.metadata=null;return}
try{const art=st.cover||st.img||st.image;ms.metadata=new MediaMetadata({title:st.title||st.t||'',artist:st.artist||st.a||'',artwork:art&&/^https?:/.test(art)?[{src:art}]:[]})}catch(e){}}
const noop=()=>{};
window.tuneify={
 search:memoSearch,artist:(s,a)=>guard(artist(s,a)),playlist:(s,p)=>guard(playlist(s,p)),
 resolve:t=>guard(resolve({src:t.src,rid:t.rid,sid:t.sid,title:t.title,artist:t.artist,dur:t.dur})),
 version:async()=>'1.1 beta · Android',pick,saveTrack,onMedia,presence,
 discordId:noop,miniOpen:noop,miniClose:noop,miniUpdate:noop,media:noop,min:noop,max:noop,close:noop,onMini:noop,
 vk:{getToken:async()=>getVkToken(),setToken:async t=>setVkToken(t||''),test:async t=>vkAudioTest(t),
  openOAuth:async()=>{const u='https://oauth.vk.com/authorize?client_id=2685278&scope=audio,audiooffline,offline&display=page&redirect_uri=https://oauth.vk.com/blank.html&response_type=token';window.open(u,'_blank');return u}}
};
})();
